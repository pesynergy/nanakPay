<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Report;
use App\Model\Api;
use App\User;

class CallbackController extends Controller
{
}
